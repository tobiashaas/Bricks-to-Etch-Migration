<?php
/**
 * API Client for Bricks to Etch Migration Plugin
 * 
 * Handles communication with target site API
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class B2E_API_Client {
    
    /**
     * Error handler instance
     */
    private $error_handler;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->error_handler = new B2E_Error_Handler();
    }
    
    /**
     * Send request to target site
     */
    private function send_request($url, $api_key, $endpoint, $method = 'GET', $data = null) {
        $full_url = rtrim($url, '/') . '/wp-json/b2e/v1' . $endpoint;
        
        $args = array(
            'method' => $method,
            'timeout' => 30,
            'headers' => array(
                'X-API-Key' => $api_key,
                'Content-Type' => 'application/json',
            ),
        );
        
        if ($data && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($full_url, $args);
        
        if (is_wp_error($response)) {
            $this->error_handler->log_error('E103', array(
                'url' => $full_url,
                'error' => $response->get_error_message(),
                'action' => 'API request failed'
            ));
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code >= 400) {
            $this->error_handler->log_error('E103', array(
                'url' => $full_url,
                'response_code' => $response_code,
                'response_body' => $response_body,
                'action' => 'API request returned error'
            ));
            return new WP_Error('api_error', 'API request failed with code: ' . $response_code);
        }
        
        $decoded_response = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->error_handler->log_error('E103', array(
                'url' => $full_url,
                'json_error' => json_last_error_msg(),
                'response_body' => $response_body,
                'action' => 'Failed to decode API response'
            ));
            return new WP_Error('json_decode_error', 'Failed to decode API response');
        }
        
        return $decoded_response;
    }
    
    /**
     * Validate API connection
     */
    public function validate_connection($url, $api_key) {
        $result = $this->send_request($url, $api_key, '/auth/validate', 'POST', array(
            'api_key' => $api_key
        ));
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return $result['valid'] ?? false;
    }
    
    /**
     * Get target site plugins
     */
    public function get_target_plugins($url, $api_key) {
        return $this->send_request($url, $api_key, '/validate/plugins');
    }
    
    /**
     * Send custom post types
     */
    public function send_custom_post_types($url, $api_key, $cpts) {
        return $this->send_request($url, $api_key, '/import/cpts', 'POST', $cpts);
    }
    
    /**
     * Send ACF field groups
     */
    public function send_acf_field_groups($url, $api_key, $field_groups) {
        return $this->send_request($url, $api_key, '/import/acf-field-groups', 'POST', $field_groups);
    }
    
    /**
     * Send MetaBox configurations
     */
    public function send_metabox_configs($url, $api_key, $configs) {
        return $this->send_request($url, $api_key, '/import/metabox-configs', 'POST', $configs);
    }
    
    /**
     * Send CSS classes
     */
    public function send_css_classes($url, $api_key, $css_classes) {
        return $this->send_request($url, $api_key, '/import/css-classes', 'POST', $css_classes);
    }
    
    /**
     * Send post
     */
    public function send_post($url, $api_key, $post, $etch_content) {
        $post_data = array(
            'post' => array(
                'ID' => $post->ID,
                'post_title' => $post->post_title,
                'post_type' => $post->post_type,
                'post_date' => $post->post_date,
                'post_status' => $post->post_status,
            ),
            'etch_content' => $etch_content,
        );
        
        return $this->send_request($url, $api_key, '/import/post', 'POST', $post_data);
    }
    
    /**
     * Send post meta
     */
    public function send_post_meta($url, $api_key, $post_id, $meta_data) {
        $data = array(
            'post_id' => $post_id,
            'meta' => $meta_data,
        );
        
        return $this->send_request($url, $api_key, '/import/post-meta', 'POST', $data);
    }
    
    /**
     * Get posts list from target site
     */
    public function get_posts_list($url, $api_key) {
        return $this->send_request($url, $api_key, '/export/posts');
    }
    
    /**
     * Get post content from target site
     */
    public function get_post_content($url, $api_key, $post_id) {
        return $this->send_request($url, $api_key, '/export/post/' . $post_id);
    }
    
    /**
     * Get CSS classes from target site
     */
    public function get_css_classes($url, $api_key) {
        return $this->send_request($url, $api_key, '/export/css-classes');
    }
    
    /**
     * Get custom post types from target site
     */
    public function get_custom_post_types($url, $api_key) {
        return $this->send_request($url, $api_key, '/export/cpts');
    }
    
    /**
     * Get ACF field groups from target site
     */
    public function get_acf_field_groups($url, $api_key) {
        return $this->send_request($url, $api_key, '/export/acf-field-groups');
    }
    
    /**
     * Get MetaBox configurations from target site
     */
    public function get_metabox_configs($url, $api_key) {
        return $this->send_request($url, $api_key, '/export/metabox-configs');
    }
    
    /**
     * Test API connection with detailed response
     */
    public function test_connection($url, $api_key) {
        $result = array(
            'valid' => false,
            'plugins' => array(),
            'errors' => array(),
        );
        
        // Test basic connection
        $connection_test = $this->validate_connection($url, $api_key);
        
        if (is_wp_error($connection_test)) {
            $result['errors'][] = $connection_test->get_error_message();
            return $result;
        }
        
        if (!$connection_test) {
            $result['errors'][] = 'Invalid API key';
            return $result;
        }
        
        $result['valid'] = true;
        
        // Get plugin status
        $plugins_response = $this->get_target_plugins($url, $api_key);
        
        if (is_wp_error($plugins_response)) {
            $result['errors'][] = 'Failed to get plugin status: ' . $plugins_response->get_error_message();
        } else {
            $result['plugins'] = $plugins_response;
        }
        
        return $result;
    }
    
    /**
     * Generate API key for target site
     */
    public function generate_api_key() {
        return 'b2e_' . wp_generate_password(32, false);
    }
    
    /**
     * Set API key on target site
     */
    public function set_api_key($url, $api_key) {
        // This would need to be implemented on the target site
        // For now, we'll just return the generated key
        return $api_key;
    }
    
    /**
     * Check if API key is valid
     */
    public function is_api_key_valid($url, $api_key) {
        $result = $this->validate_connection($url, $api_key);
        return !is_wp_error($result) && $result === true;
    }
    
    /**
     * Get API key expiration time
     */
    public function get_api_key_expiration($api_key) {
        // API keys are valid for 8 hours
        $created_time = get_option('b2e_api_key_created_' . md5($api_key));
        
        if (!$created_time) {
            return null;
        }
        
        $expiration_time = $created_time + (8 * HOUR_IN_SECONDS);
        return $expiration_time;
    }
    
    /**
     * Check if API key is expired
     */
    public function is_api_key_expired($api_key) {
        $expiration_time = $this->get_api_key_expiration($api_key);
        
        if (!$expiration_time) {
            return true;
        }
        
        return time() > $expiration_time;
    }
    
    /**
     * Create API key with expiration
     */
    public function create_api_key() {
        $api_key = $this->generate_api_key();
        $created_time = time();
        
        // Store creation time
        update_option('b2e_api_key_created_' . md5($api_key), $created_time);
        
        // Store the key
        update_option('b2e_api_key', $api_key);
        
        return $api_key;
    }
    
    /**
     * Cleanup expired API keys
     */
    public function cleanup_expired_keys() {
        global $wpdb;
        
        // Get all API key creation times
        $keys = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options} 
             WHERE option_name LIKE 'b2e_api_key_created_%'"
        );
        
        $current_time = time();
        $expired_keys = array();
        
        foreach ($keys as $key) {
            $created_time = intval($key->option_value);
            $expiration_time = $created_time + (8 * HOUR_IN_SECONDS);
            
            if ($current_time > $expiration_time) {
                $key_hash = str_replace('b2e_api_key_created_', '', $key->option_name);
                $expired_keys[] = $key_hash;
                
                // Delete the creation time record
                delete_option($key->option_name);
            }
        }
        
        return $expired_keys;
    }
}
