<?php
/**
 * Gutenberg Generator for Bricks to Etch Migration Plugin
 * 
 * Generates Etch-compatible Gutenberg blocks from Bricks elements
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class B2E_Gutenberg_Generator {
    
    /**
     * Error handler instance
     */
    private $error_handler;
    
    /**
     * Dynamic data converter instance
     */
    private $dynamic_data_converter;
    
    /**
     * Content parser instance
     */
    private $content_parser;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->error_handler = new B2E_Error_Handler();
        $this->dynamic_data_converter = new B2E_Dynamic_Data_Converter();
        $this->content_parser = new B2E_Content_Parser();
    }
    
    /**
     * Convert Bricks elements directly to Gutenberg HTML (SIMPLE & DIRECT)
     */
    private function convert_bricks_to_gutenberg_html($bricks_elements, $post) {
        if (empty($bricks_elements) || !is_array($bricks_elements)) {
            return '';
        }
        
        $html_parts = array();
        
        // Build element map for hierarchy
        $element_map = array();
        foreach ($bricks_elements as $element) {
            if (isset($element['id'])) {
                $element_map[$element['id']] = $element;
            }
        }
        
        // Find root elements (parent = 0 or '0')
        $root_elements = array();
        foreach ($bricks_elements as $element) {
            $parent = $element['parent'] ?? '0';
            if ($parent === 0 || $parent === '0' || $parent === '') {
                $root_elements[] = $element;
            }
        }
        
        // Convert each root element
        foreach ($root_elements as $element) {
            $block_html = $this->convert_single_bricks_element($element, $element_map);
            if (!empty($block_html)) {
                $html_parts[] = $block_html;
            }
        }
        
        return implode("\n\n", $html_parts);
    }
    
    /**
     * Convert a single Bricks element to Etch block
     */
    private function convert_single_bricks_element($element, $element_map) {
        $element_type = $element['name'] ?? '';
        $element_id = $element['id'] ?? '';
        $settings = $element['settings'] ?? array();
        $children_ids = $element['children'] ?? array();
        
        // Get children elements
        $children = array();
        foreach ($children_ids as $child_id) {
            if (isset($element_map[$child_id])) {
                $children[] = $element_map[$child_id];
            }
        }
        
        // Convert based on element type to ETCH blocks
        switch ($element_type) {
            case 'section':
                return $this->convert_etch_section($element, $children, $element_map);
            
            case 'container':
                return $this->convert_etch_container($element, $children, $element_map);
            
            case 'block':
            case 'div':
                return $this->convert_etch_div($element, $children, $element_map);
            
            case 'text':
            case 'text-basic':
                return $this->convert_etch_text($element);
            
            case 'heading':
                return $this->convert_etch_heading($element);
            
            case 'image':
                return $this->convert_etch_image($element);
            
            case 'icon':
                return $this->convert_etch_icon($element);
            
            case 'button':
                return $this->convert_etch_button($element);
            
            case 'code':
            case 'filter-radio':
            case 'form':
            case 'map':
                // Convert unsupported elements to div
                return $this->convert_etch_div($element, $children, $element_map);
            
            default:
                // Wrap unknown elements - render children
                $child_html = '';
                foreach ($children as $child) {
                    $child_html .= $this->convert_single_bricks_element($child, $element_map);
                }
                return $child_html;
        }
    }
    
    /**
     * Convert Bricks Section to Etch Section (wp:group with proper etchData)
     */
    private function convert_etch_section($element, $children, $element_map) {
        $classes = $this->get_element_classes($element);
        $settings = $element['settings'] ?? array();
        $label = $element['label'] ?? '';
        
        // Convert children
        $children_html = '';
        foreach ($children as $child) {
            $child_html = $this->convert_single_bricks_element($child, $element_map);
            if (!empty($child_html)) {
                $children_html .= $child_html . "\n";
            }
        }
        
        // Build Etch-compatible attributes
        $etch_attributes = array(
            'data-etch-element' => 'section'
        );
        
        // Add class to attributes if exists
        if (!empty($classes)) {
            $etch_attributes['class'] = implode(' ', $classes);
        }
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Add default section style
        array_unshift($style_ids, 'etch-section-style');
        
        // Build attributes JSON with FULL Etch structure
        $attrs = array(
            'metadata' => array(
                'name' => $label ?: 'Section',
                'etchData' => array(
                    'origin' => 'etch',
                    'name' => $label ?: 'Section',
                    'styles' => $style_ids,
                    'attributes' => $etch_attributes,
                    'block' => array(
                        'type' => 'html',
                        'tag' => 'section'
                    )
                )
            )
        );
        
        $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
        
        // Build class attribute for HTML (Etch uses <div> in HTML, renders based on block.tag)
        $class_attr = !empty($classes) ? ' class="wp-block-group ' . esc_attr(implode(' ', $classes)) . '"' : ' class="wp-block-group"';
        
        // Etch Section = wp:group with <div> (rendered as <section> by Etch)
        return '<!-- wp:group ' . $attrs_json . ' -->' . "\n" .
               '<div' . $class_attr . '>' . "\n" .
               $children_html .
               '</div>' . "\n" .
               '<!-- /wp:group -->';
    }
    
    /**
     * Convert Bricks Container to Etch Container (wp:group with proper etchData)
     */
    private function convert_etch_container($element, $children, $element_map) {
        $classes = $this->get_element_classes($element);
        $label = $element['label'] ?? '';
        
        // Convert children
        $children_html = '';
        foreach ($children as $child) {
            $child_html = $this->convert_single_bricks_element($child, $element_map);
            if (!empty($child_html)) {
                $children_html .= $child_html . "\n";
            }
        }
        
        // Build Etch-compatible attributes
        $etch_attributes = array(
            'data-etch-element' => 'container'
        );
        
        // Add class to attributes if exists
        if (!empty($classes)) {
            $etch_attributes['class'] = implode(' ', $classes);
        }
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Add default container style
        array_unshift($style_ids, 'etch-container-style');
        
        // Build attributes JSON with FULL Etch structure
        $attrs = array(
            'metadata' => array(
                'name' => $label ?: 'Container',
                'etchData' => array(
                    'origin' => 'etch',
                    'name' => $label ?: 'Container',
                    'styles' => $style_ids,
                    'attributes' => $etch_attributes,
                    'block' => array(
                        'type' => 'html',
                        'tag' => 'div'
                    )
                )
            )
        );
        
        $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
        
        // Build class attribute for HTML
        $class_attr = !empty($classes) ? ' class="wp-block-group ' . esc_attr(implode(' ', $classes)) . '"' : ' class="wp-block-group"';
        
        // Etch Container = wp:group
        return '<!-- wp:group ' . $attrs_json . ' -->' . "\n" .
               '<div' . $class_attr . '>' . "\n" .
               $children_html .
               '</div>' . "\n" .
               '<!-- /wp:group -->';
    }
    
    /**
     * Convert Bricks Div to Etch Flex-Div (wp:group with proper etchData)
     */
    private function convert_etch_div($element, $children, $element_map) {
        $classes = $this->get_element_classes($element);
        $label = $element['label'] ?? '';
        
        // Convert children
        $children_html = '';
        foreach ($children as $child) {
            $child_html = $this->convert_single_bricks_element($child, $element_map);
            if (!empty($child_html)) {
                $children_html .= $child_html . "\n";
            }
        }
        
        // Build Etch-compatible attributes for flex-div
        $etch_attributes = array(
            'data-etch-element' => 'flex-div'
        );
        
        // Add class to attributes if exists
        if (!empty($classes)) {
            $etch_attributes['class'] = implode(' ', $classes);
        }
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Add default flex-div style
        array_unshift($style_ids, 'etch-flex-div-style');
        
        // Build attributes JSON with FULL Etch structure
        $attrs = array(
            'metadata' => array(
                'name' => $label ?: 'Flex Div',
                'etchData' => array(
                    'origin' => 'etch',
                    'name' => $label ?: 'Flex Div',
                    'styles' => $style_ids,
                    'attributes' => $etch_attributes,
                    'block' => array(
                        'type' => 'html',
                        'tag' => 'div'
                    )
                )
            )
        );
        
        $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
        
        // Build class attribute for HTML
        $class_attr = !empty($classes) ? ' class="wp-block-group ' . esc_attr(implode(' ', $classes)) . '"' : ' class="wp-block-group"';
        
        // Etch Div = wp:group
        return '<!-- wp:group ' . $attrs_json . ' -->' . "\n" .
               '<div' . $class_attr . '>' . "\n" .
               $children_html .
               '</div>' . "\n" .
               '<!-- /wp:group -->';
    }
    
    /**
     * Convert Bricks Text to standard paragraph with Etch metadata
     */
    private function convert_etch_text($element) {
        $text = $element['settings']['text'] ?? '';
        $label = $element['label'] ?? '';
        
        if (empty($text)) {
            return '';
        }
        
        $classes = $this->get_element_classes($element);
        $class_attr = !empty($classes) ? ' class="' . esc_attr(implode(' ', $classes)) . '"' : '';
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Build attributes with Etch metadata
        $attrs = array();
        
        // Add etchData with styles
        if (!empty($style_ids) || !empty($classes)) {
            $etch_data = array(
                'origin' => 'etch',
                'name' => $label ?: 'Text',
                'styles' => $style_ids,
                'attributes' => array(),
                'block' => array(
                    'type' => 'html',
                    'tag' => 'p'
                )
            );
            
            if (!empty($classes)) {
                $etch_data['attributes']['class'] = implode(' ', $classes);
            }
            
            $attrs['metadata'] = array(
                'name' => $label ?: 'Text',
                'etchData' => $etch_data
            );
        }
        
        if (!empty($classes)) {
            $attrs['className'] = implode(' ', $classes);
        }
        
        $attrs_json = !empty($attrs) ? ' ' . json_encode($attrs, JSON_UNESCAPED_UNICODE) : '';
        
        // Use standard wp:paragraph
        return '<!-- wp:paragraph' . $attrs_json . ' -->' . "\n" .
               '<p' . $class_attr . '>' . $text . '</p>' . "\n" .
               '<!-- /wp:paragraph -->';
    }
    
    /**
     * Convert Bricks Heading to standard heading with Etch metadata
     */
    private function convert_etch_heading($element) {
        $text = $element['settings']['text'] ?? '';
        $tag = $element['settings']['tag'] ?? 'h2';
        $label = $element['label'] ?? '';
        
        if (empty($text)) {
            return '';
        }
        
        $classes = $this->get_element_classes($element);
        $base_classes = array('wp-block-heading');
        if (!empty($classes)) {
            $base_classes = array_merge($base_classes, $classes);
        }
        $class_attr = ' class="' . esc_attr(implode(' ', $base_classes)) . '"';
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Build attributes with Etch metadata
        $attrs = array();
        
        // Add etchData with styles
        if (!empty($style_ids) || !empty($classes)) {
            $etch_data = array(
                'origin' => 'etch',
                'name' => $label ?: 'Heading',
                'styles' => $style_ids,
                'attributes' => array(),
                'block' => array(
                    'type' => 'html',
                    'tag' => $tag
                )
            );
            
            if (!empty($classes)) {
                $etch_data['attributes']['class'] = implode(' ', $classes);
            }
            
            $attrs['metadata'] = array(
                'name' => $label ?: 'Heading',
                'etchData' => $etch_data
            );
        }
        
        if (!empty($classes)) {
            $attrs['className'] = implode(' ', $classes);
        }
        
        // Add level attribute for heading
        $level = (int) str_replace('h', '', $tag);
        if ($level >= 1 && $level <= 6) {
            $attrs['level'] = $level;
        }
        
        $attrs_json = !empty($attrs) ? ' ' . json_encode($attrs, JSON_UNESCAPED_UNICODE) : '';
        
        // Use standard wp:heading
        return '<!-- wp:heading' . $attrs_json . ' -->' . "\n" .
               '<' . $tag . $class_attr . '>' . $text . '</' . $tag . '>' . "\n" .
               '<!-- /wp:heading -->';
    }
    
    /**
     * Convert Bricks Image to standard image
     */
    private function convert_etch_image($element) {
        $image_id = $element['settings']['image']['id'] ?? '';
        $image_url = $element['settings']['image']['url'] ?? '';
        $label = $element['label'] ?? '';
        
        if (empty($image_url)) {
            return '';
        }
        
        $classes = $this->get_element_classes($element);
        
        // Get style IDs for this element
        $style_ids = $this->get_element_style_ids($element);
        
        // Build attributes with Etch nestedData structure for img classes
        $attrs = array(
            'metadata' => array(
                'name' => $label ?: 'Image',
                'etchData' => array(
                    'removeWrapper' => true,
                    'block' => array(
                        'type' => 'html',
                        'tag' => 'figure'
                    ),
                    'origin' => 'etch',
                    'name' => $label ?: 'Image',
                    'nestedData' => array(
                        'img' => array(
                            'origin' => 'etch',
                            'name' => $label ?: 'Image',
                            'styles' => $style_ids,
                            'attributes' => array(
                                'src' => $image_url,
                                'class' => !empty($classes) ? implode(' ', $classes) : ''
                            ),
                            'block' => array(
                                'type' => 'html',
                                'tag' => 'img'
                            )
                        )
                    )
                )
            )
        );
        
        $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
        
        // Use standard wp:image with Etch nestedData
        return '<!-- wp:image ' . $attrs_json . ' -->' . "\n" .
               '<figure class="wp-block-image"><img src="' . esc_url($image_url) . '" alt=""/></figure>' . "\n" .
               '<!-- /wp:image -->';
    }
    
    /**
     * Convert Bricks Icon to Etch SVG or Icon element
     */
    private function convert_etch_icon($element) {
        $icon_library = $element['settings']['icon']['library'] ?? '';
        $icon_value = $element['settings']['icon']['icon'] ?? '';
        $svg_code = $element['settings']['icon']['svg'] ?? '';
        $label = $element['label'] ?? '';
        
        if (empty($icon_value) && empty($svg_code)) {
            return '';
        }
        
        $classes = $this->get_element_classes($element);
        $style_ids = $this->get_element_style_ids($element);
        
        // Check if it's an SVG or FontAwesome icon
        if (!empty($svg_code) || strpos($icon_library, 'svg') !== false) {
            // SVG Icon - use Etch SVG element
            $attrs = array(
                'metadata' => array(
                    'name' => $label ?: 'SVG',
                    'etchData' => array(
                        'origin' => 'etch',
                        'name' => $label ?: 'SVG',
                        'styles' => $style_ids,
                        'attributes' => array(
                            'src' => $svg_code ?: '', // SVG code or URL
                            'stripColors' => 'true'
                        ),
                        'block' => array(
                            'type' => 'html',
                            'tag' => 'svg',
                            'specialized' => 'svg'
                        )
                    )
                )
            );
            
            if (!empty($classes)) {
                $attrs['className'] = implode(' ', $classes);
            }
            
            $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
            
            return '<!-- wp:group ' . $attrs_json . ' -->' . "\n" .
                   '<div class="wp-block-group"></div>' . "\n" .
                   '<!-- /wp:group -->';
        } else {
            // FontAwesome or other icon font - use HTML block with <i>
            $attrs = array(
                'metadata' => array(
                    'name' => $label ?: 'Icon',
                    'etchData' => array(
                        'origin' => 'etch',
                        'name' => $label ?: 'Icon',
                        'styles' => $style_ids,
                        'attributes' => array(
                            'class' => $icon_value
                        ),
                        'block' => array(
                            'type' => 'html',
                            'tag' => 'i'
                        )
                    )
                )
            );
            
            if (!empty($classes)) {
                $attrs['className'] = implode(' ', $classes);
            }
            
            $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
            
            $class_attr = !empty($classes) ? ' class="' . esc_attr(implode(' ', $classes)) . '"' : '';
            
            return '<!-- wp:html ' . $attrs_json . ' -->' . "\n" .
                   '<i' . $class_attr . ' class="' . esc_attr($icon_value) . '"></i>' . "\n" .
                   '<!-- /wp:html -->';
        }
    }
    
    /**
     * Convert Bricks Button to Etch Link (Anchor)
     */
    private function convert_etch_button($element) {
        $text = $element['settings']['text'] ?? 'Button';
        $link = $element['settings']['link'] ?? '#';
        $label = $element['label'] ?? '';
        
        // Handle Bricks link format (can be array or string)
        if (is_array($link)) {
            $url = $link['url'] ?? '#';
            $target = $link['newTab'] ?? false;
        } else {
            $url = $link;
            $target = false;
        }
        
        $classes = $this->get_element_classes($element);
        $style_ids = $this->get_element_style_ids($element);
        
        // Generate unique ref ID for the link
        $ref_id = substr(md5($element['id'] ?? uniqid()), 0, 7);
        
        // Build Etch Link with nestedData (like Anchor element)
        $link_attrs = array(
            'href' => $url
        );
        
        if ($target) {
            $link_attrs['target'] = '_blank';
            $link_attrs['rel'] = 'noopener';
        }
        
        if (!empty($classes)) {
            $link_attrs['class'] = implode(' ', $classes);
        }
        
        $attrs = array(
            'metadata' => array(
                'name' => $label ?: 'Anchor',
                'etchData' => array(
                    'removeWrapper' => true,
                    'block' => array(
                        'type' => 'html',
                        'tag' => 'p'
                    ),
                    'origin' => 'etch',
                    'name' => $label ?: 'Anchor',
                    'nestedData' => array(
                        $ref_id => array(
                            'origin' => 'etch',
                            'name' => $label ?: 'Anchor',
                            'styles' => $style_ids,
                            'attributes' => $link_attrs,
                            'block' => array(
                                'type' => 'html',
                                'tag' => 'a'
                            )
                        )
                    )
                )
            )
        );
        
        $attrs_json = json_encode($attrs, JSON_UNESCAPED_UNICODE);
        
        // Use wp:paragraph with nested anchor (Etch Link structure)
        return '<!-- wp:paragraph ' . $attrs_json . ' -->' . "\n" .
               '<p><a data-etch-ref="' . $ref_id . '">' . esc_html($text) . '</a></p>' . "\n" .
               '<!-- /wp:paragraph -->';
    }
    
    /**
     * Get element classes (resolve IDs to names)
     */
    private function get_element_classes($element) {
        $classes = array();
        
        // Global classes - resolve IDs to names
        if (isset($element['settings']['_cssGlobalClasses']) && is_array($element['settings']['_cssGlobalClasses'])) {
            $global_classes = get_option('bricks_global_classes', array());
            
            foreach ($element['settings']['_cssGlobalClasses'] as $class_id) {
                // Find the class by ID
                foreach ($global_classes as $global_class) {
                    if (isset($global_class['id']) && $global_class['id'] === $class_id) {
                        if (isset($global_class['name'])) {
                            $classes[] = $global_class['name'];
                        }
                        break;
                    }
                }
            }
        }
        
        // Custom classes (these are already names, not IDs)
        if (isset($element['settings']['_cssClasses']) && is_array($element['settings']['_cssClasses'])) {
            $classes = array_merge($classes, $element['settings']['_cssClasses']);
        }
        
        return $classes;
    }
    
    /**
     * Get Etch style IDs for element (convert Bricks class IDs to Etch style IDs)
     */
    private function get_element_style_ids($element) {
        $style_ids = array();
        
        // Get Bricks global class IDs
        if (isset($element['settings']['_cssGlobalClasses']) && is_array($element['settings']['_cssGlobalClasses'])) {
            // Get style map (Bricks ID => Etch ID)
            $style_map = get_option('b2e_style_map', array());
            
            foreach ($element['settings']['_cssGlobalClasses'] as $bricks_class_id) {
                // Convert Bricks ID to Etch ID
                if (isset($style_map[$bricks_class_id])) {
                    $style_ids[] = $style_map[$bricks_class_id];
                }
            }
        }
        
        return $style_ids;
    }
    
    /**
     * Generate Gutenberg blocks from Bricks elements (REAL CONVERSION!)
     */
    public function generate_gutenberg_blocks($bricks_elements) {
        if (empty($bricks_elements) || !is_array($bricks_elements)) {
            return '';
        }
        
        // Build element lookup map (id => element)
        $element_map = array();
        foreach ($bricks_elements as $element) {
            $element_map[$element['id']] = $element;
        }
        
        // Find top-level elements (parent = 0 or parent not in map)
        $top_level_elements = array();
        foreach ($bricks_elements as $element) {
            $parent_id = $element['parent'] ?? 0;
            if ($parent_id === 0 || $parent_id === '0' || !isset($element_map[$parent_id])) {
                $top_level_elements[] = $element;
            }
        }
        
        // Generate blocks for top-level elements (recursively includes children)
        $gutenberg_blocks = array();
        foreach ($top_level_elements as $element) {
            $block_html = $this->generate_block_html($element, $element_map);
            if ($block_html) {
                $gutenberg_blocks[] = $block_html;
            }
        }
        
        return implode("\n", $gutenberg_blocks);
    }
    
    /**
     * Convert Bricks to Gutenberg and save to database (FOR ECH PROCESSING!)
     */
    public function convert_bricks_to_gutenberg($post) {
        error_log("B2E: convert_bricks_to_gutenberg called for post " . $post->ID);
        
        // Check for Bricks content first
        $bricks_content = get_post_meta($post->ID, '_bricks_page_content_2', true);
        
        // If it's a JSON string, decode it
        if (is_string($bricks_content)) {
            $decoded = json_decode($bricks_content, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $bricks_content = $decoded;
            }
        }
        
        if (empty($bricks_content) || !is_array($bricks_content)) {
            $this->error_handler->log_error('I020', array(
                'post_id' => $post->ID,
                'action' => 'No Bricks content found for conversion',
                'content_type' => gettype($bricks_content)
            ));
            return false;
        }
        
        error_log("B2E: Found " . count($bricks_content) . " Bricks elements");
        
        // Convert Bricks elements directly to Gutenberg HTML (SIMPLE APPROACH)
        $gutenberg_html = $this->convert_bricks_to_gutenberg_html($bricks_content, $post);
        
        error_log("B2E: Generated HTML length: " . strlen($gutenberg_html));
        
        if (empty($gutenberg_html)) {
            $this->error_handler->log_error('I022', array(
                'post_id' => $post->ID,
                'action' => 'Failed to generate Gutenberg blocks'
            ));
            return false;
        }
        
        // Append inline JavaScript from code blocks (if any)
        $inline_js = get_option('b2e_inline_js_' . $post->ID, '');
        if (!empty($inline_js)) {
            $gutenberg_html .= "\n\n<!-- wp:html -->\n<script>\n" . trim($inline_js) . "\n</script>\n<!-- /wp:html -->";
            delete_option('b2e_inline_js_' . $post->ID);
        }
        
        // Convert HTML to blocks array
        $gutenberg_blocks = parse_blocks($gutenberg_html);
        
        // Get target site URL from settings
        $settings = get_option('b2e_settings', array());
        $target_url = $settings['target_url'] ?? '';
        
        if (empty($target_url)) {
            $this->error_handler->log_error('I024', array(
                'post_id' => $post->ID,
                'error' => 'No target URL configured',
                'action' => 'Failed to send blocks to Etch API'
            ));
            return false;
        }
        
        // Send blocks to Etch via HTTP (using custom migration endpoint without auth)
        $etch_post_id = $post->ID; // Same ID on Etch side
        $endpoint_url = rtrim($target_url, '/') . "/wp-json/b2e-migration/v1/post/{$etch_post_id}/blocks";
        
        // Prepare payload with blocks AND metadata
        $payload = array(
            'blocks' => $gutenberg_blocks,
            'metadata' => array(
                'post_title' => $post->post_title,
                'post_name' => $post->post_name,
                'post_type' => $post->post_type,
                'post_status' => $post->post_status,
                'post_excerpt' => $post->post_excerpt,
                'post_date' => $post->post_date,
                'post_author' => $post->post_author,
            )
        );
        
        // Debug log
        error_log("B2E: Sending blocks to: " . $endpoint_url);
        error_log("B2E: Post title: " . $post->post_title);
        error_log("B2E: Blocks count: " . count($gutenberg_blocks));
        
        $response = wp_remote_post($endpoint_url, array(
            'body' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 30,
        ));
        
        // Debug log response
        if (is_wp_error($response)) {
            error_log("B2E: WP_Error: " . $response->get_error_message());
        } else {
            error_log("B2E: Response code: " . wp_remote_retrieve_response_code($response));
            error_log("B2E: Response body: " . wp_remote_retrieve_body($response));
        }
        
        if (is_wp_error($response)) {
            $this->error_handler->log_error('I024', array(
                'post_id' => $post->ID,
                'error' => $response->get_error_message(),
                'action' => 'Failed to send blocks to Etch API'
            ));
            return false;
        }
        
        // Check response
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $response_body = wp_remote_retrieve_body($response);
            $this->error_handler->log_error('I024', array(
                'post_id' => $post->ID,
                'error' => "API returned {$response_code}: {$response_body}",
                'action' => 'Failed to save blocks via Etch API'
            ));
            return false;
        }
        
        // Remove Bricks meta (cleanup)
        delete_post_meta($post->ID, '_bricks_page_content');
        delete_post_meta($post->ID, '_bricks_page_settings');
        
        // Log successful conversion and API save
        $this->error_handler->log_error('I023', array(
            'post_id' => $post->ID,
            'post_title' => $post->post_title,
            'bricks_elements' => count($bricks_content),
            'blocks_generated' => count($gutenberg_blocks),
            'api_method' => 'Custom Migration Endpoint via HTTP',
            'database_updated' => true,
            'bricks_meta_cleaned' => true,
            'action' => 'Bricks converted to Gutenberg blocks and saved via Etch API'
        ));
        
        return true;
    }
    
    /**
     * Generate HTML for a single block
     */
    private function generate_block_html($element, $element_map = array()) {
        $etch_type = $element['etch_type'] ?? 'generic';
        
        // Skip elements marked for skipping (e.g., code blocks)
        if ($etch_type === 'skip') {
            return '';
        }
        
        switch ($etch_type) {
            case 'section':
            case 'container':
            case 'flex-div':
            case 'iframe':
                return $this->generate_etch_group_block($element, $element_map);
                
            case 'heading':
            case 'paragraph':
            case 'image':
            case 'button':
                return $this->generate_standard_block($element);
                
            case 'skip':
                return ''; // Skip this element
                
            default:
                return $this->generate_generic_block($element);
        }
    }
    
    /**
     * Generate Etch group block (wp:group with etchData)
     */
    private function generate_etch_group_block($element, $element_map = array()) {
        $etch_data = $element['etch_data'] ?? array();
        $content = $element['content'] ?? '';
        
        // Convert dynamic data in content
        $content = $this->dynamic_data_converter->convert_content($content);
        
        // Extract style IDs
        $style_ids = $this->extract_style_ids($element['settings'] ?? array());
        
        // Use custom label if available, otherwise use element type
        $element_name = !empty($element['label']) ? $element['label'] : ucfirst($element['etch_type']);
        
        // Extract class for Gutenberg className
        $class_name = !empty($etch_data['class']) ? $etch_data['class'] : '';
        
        // Keep class in etchData attributes for Etch to render
        // Etch ignores the HTML class attribute and only uses etchData
        $etch_data_attributes = $etch_data;
        
        // Build etchData
        $etch_data_array = array(
            'origin' => 'etch',
            'name' => $element_name,
            'styles' => $style_ids,
            'attributes' => $etch_data_attributes,
            'block' => array(
                'type' => 'html',
                'tag' => $this->get_html_tag($element['etch_type']),
            ),
        );
        
        // Generate Gutenberg block
        $block_content = $this->generate_block_content($element, $content, $element_map);
        
        // Build block attributes
        $block_attrs = array(
            'metadata' => array(
                'name' => $etch_data_array['name'],
                'etchData' => $etch_data_array
            )
        );
        
        // Add className for Gutenberg (extracted earlier to avoid duplication)
        if (!empty($class_name)) {
            $block_attrs['className'] = $class_name;
        }
        
        // Add tagName for non-div elements (section, article, etc.)
        $html_tag = $this->get_html_tag($element['etch_type']);
        if ($html_tag !== 'div') {
            $block_attrs['tagName'] = $html_tag;
        }
        
        $gutenberg_html = sprintf(
            '<!-- wp:group %s -->',
            json_encode($block_attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
        
        // Add classes to the HTML element
        $classes = array('wp-block-group');
        if (!empty($class_name)) {
            $classes[] = $class_name;
        }
        $class_attr = ' class="' . esc_attr(implode(' ', $classes)) . '"';
        
        $gutenberg_html .= "\n<div" . $class_attr . ">";
        $gutenberg_html .= "\n" . $block_content;
        $gutenberg_html .= "\n</div>";
        $gutenberg_html .= "\n<!-- /wp:group -->";
        
        return $gutenberg_html;
    }
    
    /**
     * Generate standard Gutenberg block
     */
    private function generate_standard_block($element) {
        $etch_type = $element['etch_type'];
        $etch_data = $element['etch_data'] ?? array();
        
        // Get content from etch_data or element
        $content = $etch_data['content'] ?? $element['content'] ?? '';
        
        // Convert dynamic data in content
        $content = $this->dynamic_data_converter->convert_content($content);
        
        switch ($etch_type) {
            case 'heading':
                $level = $etch_data['level'] ?? 'h2';
                $class = !empty($etch_data['class']) ? ' class="' . esc_attr($etch_data['class']) . '"' : '';
                
                // Build block attributes
                $block_attrs = array('level' => intval(str_replace('h', '', $level)));
                if (!empty($etch_data['class'])) {
                    $block_attrs['className'] = $etch_data['class'];
                }
                
                return sprintf(
                    '<!-- wp:heading %s -->',
                    json_encode($block_attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ) . "\n" . 
                '<' . $level . $class . '>' . $content . '</' . $level . '>' . "\n" .
                '<!-- /wp:heading -->';
                
            case 'paragraph':
                $class = !empty($etch_data['class']) ? ' class="' . esc_attr($etch_data['class']) . '"' : '';
                
                // Build block attributes
                $block_attrs = array();
                if (!empty($etch_data['class'])) {
                    $block_attrs['className'] = $etch_data['class'];
                }
                
                $attrs_json = !empty($block_attrs) ? ' ' . json_encode($block_attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
                
                return '<!-- wp:paragraph' . $attrs_json . ' -->' . "\n" .
                       '<p' . $class . '>' . $content . '</p>' . "\n" .
                       '<!-- /wp:paragraph -->';
                       
            case 'image':
                $src = $etch_data['src'] ?? '';
                $alt = $etch_data['alt'] ?? '';
                $class = !empty($etch_data['class']) ? ' ' . esc_attr($etch_data['class']) : '';
                
                if (empty($src)) {
                    return ''; // Skip images without source
                }
                
                // Gutenberg expects inline HTML for images (no line breaks)
                return '<!-- wp:image -->' . "\n" .
                       '<figure class="wp-block-image' . $class . '"><img src="' . esc_url($src) . '" alt="' . esc_attr($alt) . '"/></figure>' . "\n" .
                       '<!-- /wp:image -->';
                       
            case 'button':
                $href = $etch_data['href'] ?? '#';
                $target = $etch_data['target'] ?? '_self';
                $class = !empty($etch_data['class']) ? ' class="' . esc_attr($etch_data['class']) . '"' : '';
                
                return '<!-- wp:buttons -->' . "\n" .
                       '<div class="wp-block-buttons">' . "\n" .
                       '<!-- wp:button -->' . "\n" .
                       '<div class="wp-block-button' . $class . '">' . "\n" .
                       '<a class="wp-block-button__link" href="' . esc_url($href) . '" target="' . esc_attr($target) . '">' . $content . '</a>' . "\n" .
                       '</div>' . "\n" .
                       '<!-- /wp:button -->' . "\n" .
                       '</div>' . "\n" .
                       '<!-- /wp:buttons -->';
                       
            default:
                return $this->generate_generic_block($element);
        }
    }
    
    /**
     * Generate generic block (fallback)
     */
    private function generate_generic_block($element) {
        $content = $element['content'] ?? '';
        $etch_data = $element['etch_data'] ?? array();
        
        // Convert dynamic data in content
        $content = $this->dynamic_data_converter->convert_content($content);
        
        $class = !empty($etch_data['class']) ? ' class="' . esc_attr($etch_data['class']) . '"' : '';
        
        return '<!-- wp:html -->' . "\n" .
               '<div' . $class . '>' . $content . '</div>' . "\n" .
               '<!-- /wp:html -->';
    }
    
    /**
     * Generate block content
     */
    private function generate_block_content($element, $content, $element_map = array()) {
        // Handle children elements
        if (!empty($element['children']) && is_array($element['children']) && !empty($element_map)) {
            $children_blocks = array();
            
            foreach ($element['children'] as $child_id) {
                // Find child element in map
                if (isset($element_map[$child_id])) {
                    $child_element = $element_map[$child_id];
                    $child_html = $this->generate_block_html($child_element, $element_map);
                    if ($child_html) {
                        $children_blocks[] = $child_html;
                    }
                }
            }
            
            return implode("\n", $children_blocks);
        }
        
        return $content;
    }
    
    /**
     * Extract style IDs from element settings
     */
    private function extract_style_ids($settings) {
        $style_ids = array();
        
        // Add Etch element style
        $etch_type = $settings['etch_type'] ?? '';
        if ($etch_type) {
            $style_ids[] = 'etch-' . $etch_type . '-style';
        }
        
        // Extract CSS classes and convert to style IDs
        if (!empty($settings['_cssClasses'])) {
            $style_ids[] = $this->generate_style_hash($settings['_cssClasses']);
        }
        
        if (!empty($settings['_cssGlobalClasses']) && is_array($settings['_cssGlobalClasses'])) {
            foreach ($settings['_cssGlobalClasses'] as $global_class) {
                $style_ids[] = $this->generate_style_hash($global_class);
            }
        }
        
        return array_unique($style_ids);
    }
    
    /**
     * Generate 7-character hash ID for styles
     */
    private function generate_style_hash($class_name) {
        return substr(md5($class_name), 0, 7);
    }
    
    /**
     * Get HTML tag for Etch element type
     */
    private function get_html_tag($etch_type) {
        switch ($etch_type) {
            case 'section':
                return 'section';
            case 'container':
                return 'div';
            case 'flex-div':
                return 'div';
            case 'iframe':
                return 'iframe';
            default:
                return 'div';
        }
    }
    
    /**
     * Process element by type (called from Content Parser)
     */
    public function process_element_by_type($element, $post_id) {
        $element_name = $element['name'];
        
        switch ($element_name) {
            case 'section':
                return $this->process_section_element($element, $post_id);
                
            case 'container':
                return $this->process_container_element($element, $post_id);
                
            case 'div':
                return $this->process_div_element($element, $post_id);
                
            case 'heading':
                return $this->process_heading_element($element, $post_id);
                
            case 'text':
                return $this->process_text_element($element, $post_id);
                
            case 'image':
                return $this->process_image_element($element, $post_id);
                
            case 'button':
                return $this->process_button_element($element, $post_id);
                
            case 'video':
            case 'video-iframe':
                return $this->process_video_element($element, $post_id);
                
            case 'iframe':
                return $this->process_iframe_element($element, $post_id);
                
            default:
                return $this->process_generic_element($element, $post_id);
        }
    }
    
    /**
     * Process section element
     */
    private function process_section_element($element, $post_id) {
        $element['etch_type'] = 'section';
        $element['etch_data'] = array(
            'data-etch-element' => 'section',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process container element
     */
    private function process_container_element($element, $post_id) {
        $element['etch_type'] = 'container';
        $element['etch_data'] = array(
            'data-etch-element' => 'container',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process div element
     */
    private function process_div_element($element, $post_id) {
        $settings = get_option('b2e_settings', array());
        $convert_div_to_flex = $settings['convert_div_to_flex'] ?? true;
        
        if ($convert_div_to_flex) {
            $element['etch_type'] = 'flex-div';
            $element['etch_data'] = array(
                'data-etch-element' => 'flex-div',
                'class' => $this->extract_css_classes($element['settings']),
            );
        } else {
            $element['etch_type'] = 'skip';
        }
        
        return $element;
    }
    
    /**
     * Process heading element
     */
    private function process_heading_element($element, $post_id) {
        $element['etch_type'] = 'heading';
        $element['etch_data'] = array(
            'level' => $element['settings']['tag'] ?? 'h2',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process text element
     */
    private function process_text_element($element, $post_id) {
        $element['etch_type'] = 'paragraph';
        $element['etch_data'] = array(
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process image element
     */
    private function process_image_element($element, $post_id) {
        $element['etch_type'] = 'image';
        $element['etch_data'] = array(
            'src' => $element['settings']['image']['url'] ?? '',
            'alt' => $element['settings']['image']['alt'] ?? '',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process button element
     */
    private function process_button_element($element, $post_id) {
        $element['etch_type'] = 'button';
        $element['etch_data'] = array(
            'href' => $element['settings']['link']['url'] ?? '#',
            'target' => $element['settings']['link']['target'] ?? '_self',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process video element
     */
    private function process_video_element($element, $post_id) {
        $element['etch_type'] = 'video-iframe';
        $element['etch_data'] = array(
            'src' => $element['settings']['video']['url'] ?? '',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process iframe element
     */
    private function process_iframe_element($element, $post_id) {
        $element['etch_type'] = 'iframe';
        $element['etch_data'] = array(
            'data-etch-element' => 'iframe',
            'src' => $element['settings']['iframe']['url'] ?? '',
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Process generic element
     */
    private function process_generic_element($element, $post_id) {
        $element['etch_type'] = 'generic';
        $element['etch_data'] = array(
            'class' => $this->extract_css_classes($element['settings']),
        );
        
        return $element;
    }
    
    /**
     * Extract CSS classes from element settings
     */
    private function extract_css_classes($settings) {
        $classes = array();
        
        if (!empty($settings['_cssClasses'])) {
            $classes[] = $settings['_cssClasses'];
        }
        
        if (!empty($settings['_cssGlobalClasses']) && is_array($settings['_cssGlobalClasses'])) {
            $classes = array_merge($classes, $settings['_cssGlobalClasses']);
        }
        
        return implode(' ', array_filter($classes));
    }
}
